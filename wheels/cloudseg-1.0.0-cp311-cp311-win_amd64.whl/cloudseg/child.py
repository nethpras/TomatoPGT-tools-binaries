import sys

def main():
    # argv: subset_ply subset_keys_npz out_npz title pt_size key_scale
    subset_ply = sys.argv[1]
    subset_keys_npz = sys.argv[2]
    out_npz = sys.argv[3]
    title = sys.argv[4] if len(sys.argv) > 4 else "Select"
    pt_size = float(sys.argv[5]) if len(sys.argv) > 5 else 3.0
    key_scale = float(sys.argv[6]) if len(sys.argv) > 6 else 1e5

    from cloudseg.cs_core.cloudseg_app import run_child
    raise SystemExit(run_child(subset_ply, subset_keys_npz, out_npz, title, pt_size, key_scale))

if __name__ == "__main__":
    main()
