import multiprocessing as mp

def main():
    mp.freeze_support()
    try:
        mp.set_start_method("spawn", force=True)
    except Exception:
        pass

    from cloudgraph.cg_core.cloudgraph_app import run_app
    run_app()

if __name__ == "__main__":
    main()
